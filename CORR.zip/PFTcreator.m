function out = PFTcreator(file,variable,pft,llon,llat,ltime)
%{
Vegetation properties, and even some meteorological variables, come as
2d-arrays for all PFTs, if not averaged over grid cells:
    - p: PFT
    - t: time step
The aim of this function is to run through all PFTs, filter out the desired
one, and put together a 3d array of longitude x latitude x time.
Input parameters:
    - file:     file name
    - variable: variable within file for which to create 3d array
    - PFT:      PFT for which to assemble the 3d array of a variable.
                PFTs are:
0       not_vegetated
1       needleleaf_evergreen_temperate_tree
2       needleleaf_evergreen_boreal_tree        !!! NEBTs
3       needleleaf_deciduous_boreal_tree        !!! NDBTs
4       broadleaf_evergreen_tropical_tree
5       broadleaf_evergreen_temperate_tree
6       broadleaf_deciduous_tropical_tree
7       broadleaf_deciduous_temperate_tree
8       broadleaf_deciduous_boreal_tree         !!! BDBTs
9       broadleaf_evergreen_shrub
10      broadleaf_deciduous_temperate_shrub
11      broadleaf_deciduous_boreal_shrub        !!! BDBSs
12      c3_arctic_grass                         !!! C3AGs
13      c3_non-arctic_grass
14      c4_grass
15      c3_crop
16      c3_irrigated
In case crop module activated, additional PFTs:
17      corn                                    
18      spring_temperate_cereal                 
19      winter_temperate_cereal                 
20      soybean
%}

%------------------  importing parameters and variables  -----------------%
pfts1d_ixy = ncread(file,'pfts1d_ixy');
pfts1d_jxy = ncread(file,'pfts1d_jxy');
pfts1d_itype_veg = ncread(file,'pfts1d_itype_veg');
pfts1d_active = ncread(file,'pfts1d_active');
var = ncread(file,variable);

%------------------------------  processing  -----------------------------%
out = nan(llon,llat,ltime);
for p=1:length(pfts1d_itype_veg)
    if pfts1d_itype_veg(p) == pft && pfts1d_active(p) == 1
        out(pfts1d_ixy(p),pfts1d_jxy(p),:) = var(p,:);
    end
end

end