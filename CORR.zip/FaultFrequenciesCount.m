tic

%--------------------  basic variables and parameters  --------------------
% dimensions
load LWsub_ErrorCounting_Dimensions.mat

% indices
NEBTs = 3-1;
NETTs = 2-1;

% PFT percentages
PFTperc = ncread('surfdata_0.9x1.25_simyr2000_c130418.nc','PCT_PFT');
PFTperc_name = ncreadatt('surfdata_0.9x1.25_simyr2000_c130418.nc',...
    'PCT_PFT','long_name');
PFTperc_NETs = squeeze(PFTperc(:,:,NEBTs+1)+PFTperc(:,:,NETTs+1));


%------------------------  count unfortunate days  ------------------------
% met
load('LWsub_ErrorCounting_Insolation.mat')
load('LWsub_ErrorCounting_atmosphericLWR.mat')

% Needleleaf Evergreen Boreal Trees
load('LWsub_ErrorCounting_LWsubCtrlNEBTs.mat')
load('LWsub_ErrorCounting_LWsubLbulbNEBTs.mat')

FaultFrequenceDiff_NEBTs = nan(length(lon),length(lat));
for x=1:length(lon)
    for y=1:length(lat)
        if PFTperc(x,y,NEBTs+1) > 0
% create day/night filter
            bla = zeros(length(time),1);
            bla(SWin(x,y,:)>0) = 1;
            
% find starts of days and nights
            bums = bla(2:end)-bla(1:end-1);
            day_starts = find(bums==1);
            night_starts = find(bums==-1);
            if numel(day_starts)>0 && numel(night_starts)>0
                
% exclude first single night and last single day
                night_start = find(night_starts>day_starts(1),1);
                day_end = find(day_starts>night_starts(end),1);
                if numel(day_end) == 0
                    day_end = length(day_starts);
                end
            
% calculate day and night averages excluding polar days and nights
                DNavgCtrl = nan(day_end-1,2); DNavgLbulb = nan(day_end-1,2);
                DNatm = nan(day_end-1,2);
                for i=1:day_end-1
                    if (night_starts(night_start-1+i)-1)-(day_starts(i)) < 23
                        DNavgCtrl(i,1) = mean(LWsub_ctrl_NEBTs(x,y,day_starts(i):night_starts(night_start-1+i)-1));
                        DNavgLbulb(i,1) = mean(LWsub_lbulb_NEBTs(x,y,day_starts(i):night_starts(night_start-1+i)-1));
                        DNatm(i,1) = mean(LWatm(x,y,day_starts(i):night_starts(night_start-1+i)-1));
                    end
                    if (day_starts(i+1)-1)-(night_starts(night_start-1+i)) < 23
                        DNavgCtrl(i,2) = mean(LWsub_ctrl_NEBTs(x,y,night_starts(night_start-1+i):day_starts(i+1)-1));
                        DNavgLbulb(i,2) = mean(LWsub_lbulb_NEBTs(x,y,night_starts(night_start-1+i):day_starts(i+1)-1));
                        DNatm(i,2) = mean(LWatm(x,y,night_starts(night_start-1+i):day_starts(i+1)-1));
                    end
                end
                DNctrlDiff = DNavgCtrl(:,1)-DNavgCtrl(:,2);
                DNlbulbDiff = DNavgLbulb(:,1)-DNavgLbulb(:,2);
                DNatmDiff = DNatm(:,1)-DNatm(:,2);
                
                DNidxCtrl = nan(day_end-1,1);
                    DNidxCtrl(DNctrlDiff<0 & DNatmDiff > 0) = -1;
                FaultFrequenceCtrl ...
                    = length(find(DNidxCtrl<0))/length(find(~isnan(DNctrlDiff)));
                DNidxLbulb = nan(day_end-1,1);
                    DNidxLbulb(DNlbulbDiff<0 & DNatmDiff > 0) = -1;
                FaultFrequenceLbulb ...
                    = length(find(DNidxLbulb<0))/length(find(~isnan(DNlbulbDiff)));
                
                FaultFrequenceDiff_NEBTs(x,y) = FaultFrequenceLbulb-FaultFrequenceCtrl;   
            end
        end
    end
end
clear LWsub_ctrl_NEBTs LWsub_lbulb_NEBTs


% Needleleaf Evergreen Temperate Trees
load('LWsub_ErrorCounting_LWsubCtrlNETTs.mat')
load('LWsub_ErrorCounting_LWsubLbulbNETTs.mat')

FaultFrequenceDiff_NETTs = nan(length(lon),length(lat));
for x=1:length(lon)
    for y=1:length(lat)
        if PFTperc(x,y,NETTs+1) > 0
% create day/night filter
            bla = zeros(length(time),1);
            bla(SWin(x,y,:)>0) = 1;
            
% find starts of days and nights
            bums = bla(2:end)-bla(1:end-1);
            day_starts = find(bums==1);
            night_starts = find(bums==-1);
            if numel(day_starts)>0 && numel(night_starts)>0
                
% exclude first single night and last single day
                night_start = find(night_starts>day_starts(1),1);
                day_end = find(day_starts>night_starts(end),1);
                if numel(day_end) == 0
                    day_end = length(day_starts);
                end
            
% calculate day and night averages excluding polar days and nights
                DNavgCtrl = nan(day_end-1,2); DNavgLbulb = nan(day_end-1,2);
                DNatm = nan(day_end-1,2);
                for i=1:day_end-1
                    if (night_starts(night_start-1+i)-1)-(day_starts(i)) < 23
                        DNavgCtrl(i,1) = mean(LWsub_ctrl_NETTs(x,y,day_starts(i):night_starts(night_start-1+i)-1));
                        DNavgLbulb(i,1) = mean(LWsub_lbulb_NETTs(x,y,day_starts(i):night_starts(night_start-1+i)-1));
                        DNatm(i,1) = mean(LWatm(x,y,day_starts(i):night_starts(night_start-1+i)-1));
                    end
                    if (day_starts(i+1)-1)-(night_starts(night_start-1+i)) < 23
                        DNavgCtrl(i,2) = mean(LWsub_ctrl_NETTs(x,y,night_starts(night_start-1+i):day_starts(i+1)-1));
                        DNavgLbulb(i,2) = mean(LWsub_lbulb_NETTs(x,y,night_starts(night_start-1+i):day_starts(i+1)-1));
                        DNatm(i,2) = mean(LWatm(x,y,night_starts(night_start-1+i):day_starts(i+1)-1));
                    end
                end
                DNctrlDiff = DNavgCtrl(:,1)-DNavgCtrl(:,2);
                DNlbulbDiff = DNavgLbulb(:,1)-DNavgLbulb(:,2);
                DNatmDiff = DNatm(:,1)-DNatm(:,2);
                
                DNidxCtrl = nan(day_end-1,1);
                    DNidxCtrl(DNctrlDiff<0 & DNatmDiff > 0) = -1;
                FaultFrequenceCtrl ...
                    = length(find(DNidxCtrl<0))/length(find(~isnan(DNctrlDiff)));
                DNidxLbulb = nan(day_end-1,1);
                    DNidxLbulb(DNlbulbDiff<0 & DNatmDiff > 0) = -1;
                FaultFrequenceLbulb ...
                    = length(find(DNidxLbulb<0))/length(find(~isnan(DNlbulbDiff)));
                
                FaultFrequenceDiff_NETTs(x,y) = FaultFrequenceLbulb-FaultFrequenceCtrl;   
            end
        end
    end
end
clear LWsub_ctrl_NETTs LWsub_lbulb_NETTs

save('FaultFrequences.mat','FaultFrequenceDiff_NEBTs','FaultFrequenceDiff_NETTs')