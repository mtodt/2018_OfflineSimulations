tic

clear

%--------------------------------------------------------------------------
%------------------  !!! FILE NAMES FOR DATA IMPORT !!!  ------------------
%--------------------------------------------------------------------------
for year=1981:2016
    file_met(year-1980,:) ...
        = ['daily_1981_2016/CLM45_FinalLightbulb_CRUNCEP_MR.clm2.h0.',...
        num2str(year),'-01-01-00000.nc'];
    file_grid(year-1980,:) ...
        = ['daily_1981_2016/CLM45_FinalLightbulb_CRUNCEP_MR.clm2.h1.',...
        num2str(year),'-01-01-00000.nc'];
    file_subcell(year-1980,:) ...
        = ['daily_1981_2016/CLM45_FinalLightbulb_CRUNCEP_MR.clm2.h2.',...
        num2str(year),'-01-01-00000.nc'];
end


%--------------------------------------------------------------------------
%--------------------  basic variables and parameters  --------------------
%--------------------------------------------------------------------------

% longitude
bla = ncread(file_grid(1,:),'lon');
lon = nan(size(bla));
for x=1:length(lon)
    lon(x) = bla(x);
end
clear bla

% latitude
bla = ncread(file_grid(1,:),'lat');
lat = nan(size(bla));
for y=1:length(lat)
    lat(y) = bla(y);
end
clear bla

% time
time_ind = nan(length(file_grid(:,1)),365);
time = nan(length(file_grid(:,1))*365,1);
for n=1:length(file_grid(:,1))
    time_ind(n,:) = ncread(file_grid(n,:),'time');
    time(1+(n-1)*365:n*365) = time_ind(n,:) + datenum(1981,01,01,00,00,00);
end
save('SnowGlobal_dimensions.mat','lon','lat','time_ind','time')

% defining snow years - dates not really important overall
Jan1 = nan(length(file_grid(:,1))-1,1);      % without 1981
SYstart = nan(length(file_grid(:,1))-1,1);   % without 2016
SYend = nan(length(file_grid(:,1))-1,1);     % without 1981
for t=1:length(time)
    for year=1982:2016
        if time(t) == datenum(year,1,1)
            Jan1(year-1981) = t;
        elseif time(t) == datenum(year-1,10,1)
            SYstart(year-1981) = t;
        elseif time(t) == datenum(year,9,30)
            SYend(year-1981) = t;
        end
    end
end

NEBTs = 3-1;
NETTs = 2-1;
vegetated = 1;

PFTperc = ncread('surfdata_0.9x1.25_simyr2000_c130418.nc','PCT_PFT');
PFTperc_NETs = squeeze(PFTperc(:,:,NEBTs+1)+PFTperc(:,:,NETTs+1));

%--------------------------------------------------------------------------
%------------------  import of global simulation output  ------------------
%--------------------------------------------------------------------------

%-------------------  'snow depth (liquid water)' [mm]  -------------------
SWE_name = ncreadatt(file_grid(1,:),'H2OSNO','long_name');
%{
Unit equals [kg m^{-2}] so that we just need grid cell area and snow
fraction to calculate snow mass per grid cell.
Looks like this is already a column value, so apparently not weighed by
snow cover fraction.
%}
SWE_lbulb = nan(length(lon),length(lat),length(file_grid(:,1))*365);
for n=1:length(file_grid(:,1))
    SWE_lbulb(:,:,1+(n-1)*365:n*365) = ncread(file_grid(n,:),'H2OSNO');
end
save('Lightbulb_Global_SWE_lightbulb.mat','-v7.3','SWE_lbulb','SWE_name')

% mask for perennially snow-covered land
mask_perennial = nan(length(lon),length(lat));
for x=1:length(lon)
    for y=1:length(lat)
        if ~isnan(SWE_lbulb(x,y,1))
            mask_perennial(x,y) = 0;    % land but no perennial snow cover
            bla = nan(length(SYend),1);
            for s=1:length(SYend)
                bla(s) = max(SWE_lbulb(x,y,SYstart(s):SYend(s)));
            end
            if min(bla) > 0
                mask_perennial(x,y) = 1;    % perennial snow cover
            end
        end
    end
end

% find first snow-off day
SnowOff_lbulb = nan(length(lon),length(lat),length(Jan1));
for x=1:length(lon)
    for y=1:length(lat)
        if mask_perennial(x,y) == 1
            for t=1:length(Jan1)
                if SWE_lbulb(x,y,Jan1(t)-1) > 0 
                    if min(SWE_lbulb(x,y,Jan1(t)-1:Jan1(t)+350)) == 0
                        SnowOff_lbulb(x,y,t) ...
                            = find(SWE_lbulb(x,y,Jan1(t)-1:Jan1(t)+350)==0,1);
                    elseif min(SWE_lbulb(x,y,Jan1(t)-1:Jan1(t)+350)) > 0
                        SnowOff_lbulb(x,y,t) = 351;   % values set for maps
                    end
                elseif SWE_lbulb(x,y,Jan1(t)-1) == 0
                    SnowOff_lbulb(x,y,t) = 0;   % values set for maps
                end
            end
        end
    end
end
save('Lightbulb_Global_SnowOff_lightbulb.mat','-v7.3','SnowOff_lbulb','mask_perennial')


%--------------------  'cold content of snow' [MJ/m2]  --------------------
CCsnow_name = ncreadatt(file_subcell(1,:),'CCSNO','long_name');
%{
Newly created variable giving internal energy stored in snow and necessary
to melt it or bring water contained in snow to 0C.
%}
CCsnow_lbulb = nan(length(lon),length(lat),length(file_subcell(:,1))*365);
for n=1:length(file_subcell(:,1))
    CCsnow_lbulb(:,:,1+(n-1)*365:n*365) = GridCellCreator(file_subcell(n,:),...
        'CCSNO',length(lon),length(lat),365);
end
save('Lightbulb_Global_CCsnow_lightbulb.mat','-v7.3','CCsnow_lbulb','CCsnow_name')

% average cold content for present snow
CCsnow_lbulb(CCsnow_lbulb==0) = nan;
CCsnow_lbulb_SYavg = nan(length(lon),length(lat),length(Jan1));
for x=1:length(lon)
    for y=1:length(lat)
        if mask_perennial(x,y) == 1
            for t=1:length(Jan1)
                CCsnow_lbulb_SYavg(x,y,t)...
                    = nanmean(CCsnow_lbulb(x,y,SYstart(t):SYend(t)));
            end
        end
    end
end
save('Lightbulb_Global_CCsnowAvg_lightbulb.mat','-v7.3','CCsnow_lbulb_SYavg')


%------------------  'snow temperature (top layer)' [K]  ------------------
Tsnot_name = ncreadatt(file_grid(1,:),'SNOTTOPL','long_name');
%{
Output file states [K/m], but actual modules, where values is calculated
give [K] and a temperature is assigned to it.
%}
Tsnot_lbulb = nan(length(lon),length(lat),length(file_grid(:,1))*365);
for n=1:length(file_grid(:,1))
    Tsnot_lbulb(:,:,1+(n-1)*365:n*365) = ncread(file_grid(n,:),'SNOTTOPL');
end

for x=1:length(lon)
    for y=1:length(lat)
        if mask_perennial(x,y) == 1
            for t=1:length(time)
                if isnan(Tsnot_lbulb(x,y,t)) && SWE_lbulb(x,y,t) > 0
                    Tsnot_lbulb(x,y,t) = 273.15 - ...
                        CCsnow_lbulb(x,y,t)*10^6 /(2117.27*SWE_lbulb(x,y,t));
                end
            end
        end
    end
end
save('Lightbulb_Global_Tsnot_lightbulb.mat','-v7.3','Tsnot_lbulb','Tsnot_name')

Tsnot_lbulb_SYavg = nan(length(lon),length(lat),length(Jan1));
for x=1:length(lon)
    for y=1:length(lat)
        if mask_perennial(x,y) == 1
            for t=1:length(Jan1)
                Tsnot_lbulb_SYavg(x,y,t) ...
                    = nanmean(squeeze(Tsnot_lbulb(x,y,SYstart(t):SYend(t))));
            end
        end
    end
end
save('Lightbulb_Global_TsnotAvg_lightbulb.mat','-v7.3','Tsnot_lbulb_SYavg')

clear SWE_lbulb CCsnow_lbulb Tsnot_lbulb


%-------------------  effective emissivity of the sky  -------------------%
EmSky_name = ncreadatt(file_subcell(1,:),'EMSKY','long_name');
%{
Proxy for cloudiness, necessary for calculation of correction factors and
indicative of meteorological conditions and thus longwave enhancement.
Unitless.
%}
EmSky_NEBTs = nan(length(lon),length(lat),length(file_subcell(:,1))*365);
EmSky_NETTs = nan(length(lon),length(lat),length(file_subcell(:,1))*365);
for n=1:length(file_subcell(:,1))
    EmSky_NEBTs(:,:,1+(n-1)*365:n*365) = PFTcreator(file_subcell(n,:),...
        'EMSKY',NEBTs,length(lon),length(lat),365);
    EmSky_NETTs(:,:,1+(n-1)*365:n*365) = PFTcreator(file_subcell(n,:),...
        'EMSKY',NETTs,length(lon),length(lat),365);
end
save('Lightbulb_Global_EmSky.mat','-v7.3','EmSky_NEBTs','EmSky_NETTs','EmSky_name')

EmSky_NEBTs_DJFMAM = nan(length(lon),length(lat),length(Jan1));
EmSky_NEBTs_max = nan(length(lon),length(lat),length(Jan1));
EmSky_NEBTs_min = nan(length(lon),length(lat),length(Jan1));
EmSky_NETTs_DJFMAM = nan(length(lon),length(lat),length(Jan1));
EmSky_NETTs_max = nan(length(lon),length(lat),length(Jan1));
EmSky_NETTs_min = nan(length(lon),length(lat),length(Jan1));
for x=1:length(lon)
    for y=1:length(lat)
        if PFTperc(x,y,NEBTs+1) > 0
            for t=1:length(Jan1)
                EmSky_NEBTs_DJFMAM(x,y,t) = mean(EmSky_NEBTs(x,y,Jan1(t)-31:Jan1(t)+150));
                EmSky_NEBTs_min(x,y,t) = min(EmSky_NEBTs(x,y,Jan1(t)-31:Jan1(t)+150));
                EmSky_NEBTs_max(x,y,t) = max(EmSky_NEBTs(x,y,Jan1(t)-31:Jan1(t)+150));
            end        
        end
        if PFTperc(x,y,NETTs+1) > 0
            for t=1:length(Jan1)
                EmSky_NETTs_DJFMAM(x,y,t) = mean(EmSky_NETTs(x,y,Jan1(t)-31:Jan1(t)+150));
                EmSky_NETTs_min(x,y,t) = min(EmSky_NETTs(x,y,Jan1(t)-31:Jan1(t)+150));
                EmSky_NETTs_max(x,y,t) = max(EmSky_NETTs(x,y,Jan1(t)-31:Jan1(t)+150));
            end        
        end
    end
end
clear EmSky_NEBTs EmSky_NETTs
save('Lightbulb_Global_EmSky_Years.mat','-v7.3',...
    'EmSky_NEBTs_DJFMAM','EmSky_NEBTs_min','EmSky_NEBTs_max',...
    'EmSky_NETTs_DJFMAM','EmSky_NETTs_min','EmSky_NETTs_max')


%--------------------  atmospheric longwave radiation  --------------------
LWatm_name = ncreadatt(file_met(1,:),'FLDS','long_name');
%{
Pretty self-explanatory.
%}
LWatm = nan(length(lon),length(lat),length(file_met(:,1))*365);
for n=1:length(file_met(:,1))
    LWatm(:,:,1+(n-1)*365:n*365) = ncread(file_met(n,:),'FLDS');
end
save('Lightbulb_Global_LWatm.mat','-v7.3','LWatm','LWatm_name')


%--------------------  sub-canopy longwave radiation  --------------------%
LWsub_name = ncreadatt(file_subcell(1,:),'LWSUB','long_name');
%{
Pretty self-explanatory as well. Using self-created LWSUB instead of DLRAD,
since the latter is already multiplied by the emissivity of the ground for
absorption.
%}
LWsub_lbulb_NEBTs = nan(length(lon),length(lat),length(file_subcell(:,1))*365);
LWsub_lbulb_NETTs = nan(length(lon),length(lat),length(file_subcell(:,1))*365);
for n=1:length(file_subcell(:,1))
    LWsub_lbulb_NEBTs(:,:,1+(n-1)*365:n*365) = PFTcreator(file_subcell(n,:),...
        'LWSUB',NEBTs,length(lon),length(lat),365);
    LWsub_lbulb_NETTs(:,:,1+(n-1)*365:n*365) = PFTcreator(file_subcell(n,:),...
        'LWSUB',NETTs,length(lon),length(lat),365);
end
save('Lightbulb_Global_LWsub_lightbulb.mat','-v7.3',...
    'LWsub_lbulb_NEBTs','LWsub_lbulb_NETTs','LWsub_name')


%-------------------------  longwave enhancement  -------------------------
LWE_name = 'Longwave Enhancement';
LWE_lbulb_NEBTs = LWsub_lbulb_NEBTs./LWatm;
LWE_lbulb_NETTs = LWsub_lbulb_NETTs./LWatm;
clear LWatm LWsub_lbulb_NEBTs LWsub_lbulb_NETTs
save('Lightbulb_Global_LWE_lightbulb.mat','-v7.3',...
    'LWE_lbulb_NEBTs','LWE_lbulb_NETTs','LWE_name')

LWE_lbulb_NEBTs_DJFMAM = nan(length(lon),length(lat),length(Jan1));
LWE_lbulb_NETTs_DJFMAM = nan(length(lon),length(lat),length(Jan1));
for x=1:length(lon)
    for y=1:length(lat)
        if PFTperc(x,y,NEBTs+1) > 0
            for t=1:length(Jan1)
                LWE_lbulb_NEBTs_DJFMAM(x,y,t) ...
                    = mean(LWE_lbulb_NEBTs(x,y,Jan1(t)-31:Jan1(t)+150));
            end
        end
        if PFTperc(x,y,NETTs+1) > 0
            for t=1:length(Jan1)
                LWE_lbulb_NETTs_DJFMAM(x,y,t) ...
                    = mean(LWE_lbulb_NETTs(x,y,Jan1(t)-31:Jan1(t)+150));
            end
        end
    end
end
save('Lightbulb_Global_LWEavg_lightbulb.mat','-v7.3',...
    'LWE_lbulb_NEBTs_DJFMAM','LWE_lbulb_NETTs_DJFMAM')

toc