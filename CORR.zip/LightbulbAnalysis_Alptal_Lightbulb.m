tic
%{
Script to create .mat files for lightbulb analysis. Lightbulb simulations.
%}

%--------------------------------------------------------------------------
%------------------  !!! FILE NAMES FOR DATA IMPORT !!!  ------------------
%--------------------------------------------------------------------------
%{
Need more than one file name while running this script on laptop/esktop
computer. For usage on Oswald, the monthly files will be merged temporally
before.
%}
file_lbulb_04(1,:) = 'hourly_2004_2007/CLM45_FinalLightbulb_CRUNCEP_MR.clm2.h1.2004-01-01-00000.nc';
file_lbulb_04(2,:) = 'hourly_2004_2007/CLM45_FinalLightbulb_CRUNCEP_MR.clm2.h1.2004-01-16-00000.nc';
file_lbulb_04(3,:) = 'hourly_2004_2007/CLM45_FinalLightbulb_CRUNCEP_MR.clm2.h1.2004-01-31-00000.nc';
file_lbulb_04(4,:) = 'hourly_2004_2007/CLM45_FinalLightbulb_CRUNCEP_MR.clm2.h1.2004-02-15-00000.nc';
file_lbulb_04(5,:) = 'hourly_2004_2007/CLM45_FinalLightbulb_CRUNCEP_MR.clm2.h1.2004-03-02-00000.nc';
file_lbulb_04(6,:) = 'hourly_2004_2007/CLM45_FinalLightbulb_CRUNCEP_MR.clm2.h1.2004-03-17-00000.nc';

file_lbulb_05(1,:) = 'hourly_2004_2007/CLM45_FinalLightbulb_CRUNCEP_MR.clm2.h1.2004-12-27-00000.nc';
file_lbulb_05(2,:) = 'hourly_2004_2007/CLM45_FinalLightbulb_CRUNCEP_MR.clm2.h1.2005-01-11-00000.nc';
file_lbulb_05(3,:) = 'hourly_2004_2007/CLM45_FinalLightbulb_CRUNCEP_MR.clm2.h1.2005-01-26-00000.nc';
file_lbulb_05(4,:) = 'hourly_2004_2007/CLM45_FinalLightbulb_CRUNCEP_MR.clm2.h1.2005-02-10-00000.nc';
file_lbulb_05(5,:) = 'hourly_2004_2007/CLM45_FinalLightbulb_CRUNCEP_MR.clm2.h1.2005-02-25-00000.nc';
file_lbulb_05(6,:) = 'hourly_2004_2007/CLM45_FinalLightbulb_CRUNCEP_MR.clm2.h1.2005-03-12-00000.nc';
file_lbulb_05(7,:) = 'hourly_2004_2007/CLM45_FinalLightbulb_CRUNCEP_MR.clm2.h1.2005-03-27-00000.nc';

file_lbulb_06(1,:) = 'hourly_2004_2007/CLM45_FinalLightbulb_CRUNCEP_MR.clm2.h1.2005-12-22-00000.nc';
file_lbulb_06(2,:) = 'hourly_2004_2007/CLM45_FinalLightbulb_CRUNCEP_MR.clm2.h1.2006-01-06-00000.nc';
file_lbulb_06(3,:) = 'hourly_2004_2007/CLM45_FinalLightbulb_CRUNCEP_MR.clm2.h1.2006-01-21-00000.nc';
file_lbulb_06(4,:) = 'hourly_2004_2007/CLM45_FinalLightbulb_CRUNCEP_MR.clm2.h1.2006-02-05-00000.nc';
file_lbulb_06(5,:) = 'hourly_2004_2007/CLM45_FinalLightbulb_CRUNCEP_MR.clm2.h1.2006-02-20-00000.nc';
file_lbulb_06(6,:) = 'hourly_2004_2007/CLM45_FinalLightbulb_CRUNCEP_MR.clm2.h1.2006-03-07-00000.nc';
file_lbulb_06(7,:) = 'hourly_2004_2007/CLM45_FinalLightbulb_CRUNCEP_MR.clm2.h1.2006-03-22-00000.nc';

file_lbulb_07(1,:) = 'hourly_2004_2007/CLM45_FinalLightbulb_CRUNCEP_MR.clm2.h1.2007-01-01-00000.nc';
file_lbulb_07(2,:) = 'hourly_2004_2007/CLM45_FinalLightbulb_CRUNCEP_MR.clm2.h1.2007-01-16-00000.nc';
file_lbulb_07(3,:) = 'hourly_2004_2007/CLM45_FinalLightbulb_CRUNCEP_MR.clm2.h1.2007-01-31-00000.nc';
file_lbulb_07(4,:) = 'hourly_2004_2007/CLM45_FinalLightbulb_CRUNCEP_MR.clm2.h1.2007-02-15-00000.nc';
file_lbulb_07(5,:) = 'hourly_2004_2007/CLM45_FinalLightbulb_CRUNCEP_MR.clm2.h1.2007-03-02-00000.nc';
file_lbulb_07(6,:) = 'hourly_2004_2007/CLM45_FinalLightbulb_CRUNCEP_MR.clm2.h1.2007-03-17-00000.nc';


%--------------------------------------------------------------------------
%----------------------------  site locations  ----------------------------
%--------------------------------------------------------------------------
Abisko_loc = [16 169];      % 18.8206E, 68.3556N
Alptal_loc = [8 146];       % 8.8E, 47.05N
Borden_loc = [225 144];     % 79.9333W == 280.0667E, 44.3167N
Cherskiy_loc = [130 169];   % 161.45482E, 68.75574N
Seehornwald_loc = [9 146];  % 9.8558E, 46.8153N
Sodankyla_loc = [22 168];   % 26.6333E, 67.3667N
Yakutsk_loc = [105 163];    % 129.6189E, 62.255N
% sparse site close-ish to Sodankyla
Sparse_loc = [25 172];      % 30E, 71.15N


%--------------------------------------------------------------------------
%------------------  import of global simulation output  ------------------
%--------------------------------------------------------------------------

%-------------------------------  general  -------------------------------%
% longitude
bla = ncread(file_lbulb_04(1,:),'lon');
lon = nan(size(bla));
for x=1:length(lon)
    lon(x) = bla(x);
end

% latitude
bla = ncread(file_lbulb_04(1,:),'lat');
lat = nan(size(bla));
for y=1:length(lat)
    lat(y) = bla(y);
end

NEBTs = 3-1;
vegetated = 1;

%----------------------------  sub-canopy LWR  ----------------------------
LWsub_lbulb_Alp_04 = nan(length(file_lbulb_04(:,1))*360,1);
for n=1:length(file_lbulb_04(:,1))
    bla = PFTcreator(file_lbulb_04(n,:),'LWSUB',NEBTs,length(lon),length(lat),360);
    LWsub_lbulb_Alp_04(1+(n-1)*360:n*360) = squeeze(bla(Alptal_loc(1),Alptal_loc(2),:));
end
LWsub_lbulb_Alp_05 = nan(length(file_lbulb_05(:,1))*360,1);
for n=1:length(file_lbulb_05(:,1))
    bla = PFTcreator(file_lbulb_05(n,:),'LWSUB',NEBTs,length(lon),length(lat),360);
    LWsub_lbulb_Alp_05(1+(n-1)*360:n*360) = squeeze(bla(Alptal_loc(1),Alptal_loc(2),:));
end
LWsub_lbulb_Alp_06 = nan(length(file_lbulb_06(:,1))*360,1);
for n=1:length(file_lbulb_06(:,1))
    bla = PFTcreator(file_lbulb_06(n,:),'LWSUB',NEBTs,length(lon),length(lat),360);
    LWsub_lbulb_Alp_06(1+(n-1)*360:n*360) = squeeze(bla(Alptal_loc(1),Alptal_loc(2),:));
end
LWsub_lbulb_Alp_07 = nan(length(file_lbulb_07(:,1))*360,1);
for n=1:length(file_lbulb_07(:,1))
    bla = PFTcreator(file_lbulb_07(n,:),'LWSUB',NEBTs,length(lon),length(lat),360);
    LWsub_lbulb_Alp_07(1+(n-1)*360:n*360) = squeeze(bla(Alptal_loc(1),Alptal_loc(2),:));
end

toc
elapsedTime = toc;

save('LightbulbAnalysis_Alptal_Lightbulb_LWsub.mat','elapsedTime','lon','lat',...
    'LWsub_lbulb_Alp_04','LWsub_lbulb_Alp_05','LWsub_lbulb_Alp_06','LWsub_lbulb_Alp_07');

