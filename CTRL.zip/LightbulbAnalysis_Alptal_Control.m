tic
%{
Script to create .mat files for lightbulb analysis. Control simulation.
%}

%--------------------------------------------------------------------------
%------------------  !!! FILE NAMES FOR DATA IMPORT !!!  ------------------
%--------------------------------------------------------------------------
%{
Need more than one file name while running this script on laptop/esktop
computer. For usage on Oswald, the monthly files will be merged temporally
before.
%}
% control simulation
file_ctrl_04(1,:) = 'CLM45_NewControl_CRUNCEP_MR.clm2.h1.2004-01-01-00000.nc';
file_ctrl_04(2,:) = 'CLM45_NewControl_CRUNCEP_MR.clm2.h1.2004-01-16-00000.nc';
file_ctrl_04(3,:) = 'CLM45_NewControl_CRUNCEP_MR.clm2.h1.2004-01-31-00000.nc';
file_ctrl_04(4,:) = 'CLM45_NewControl_CRUNCEP_MR.clm2.h1.2004-02-15-00000.nc';
file_ctrl_04(5,:) = 'CLM45_NewControl_CRUNCEP_MR.clm2.h1.2004-03-02-00000.nc';
file_ctrl_04(6,:) = 'CLM45_NewControl_CRUNCEP_MR.clm2.h1.2004-03-17-00000.nc';

file_ctrl_05(1,:) = 'CLM45_NewControl_CRUNCEP_MR.clm2.h1.2004-12-27-00000.nc';
file_ctrl_05(2,:) = 'CLM45_NewControl_CRUNCEP_MR.clm2.h1.2005-01-11-00000.nc';
file_ctrl_05(3,:) = 'CLM45_NewControl_CRUNCEP_MR.clm2.h1.2005-01-26-00000.nc';
file_ctrl_05(4,:) = 'CLM45_NewControl_CRUNCEP_MR.clm2.h1.2005-02-10-00000.nc';
file_ctrl_05(5,:) = 'CLM45_NewControl_CRUNCEP_MR.clm2.h1.2005-02-25-00000.nc';
file_ctrl_05(6,:) = 'CLM45_NewControl_CRUNCEP_MR.clm2.h1.2005-03-12-00000.nc';
file_ctrl_05(7,:) = 'CLM45_NewControl_CRUNCEP_MR.clm2.h1.2005-03-27-00000.nc';

file_ctrl_06(1,:) = 'CLM45_NewControl_CRUNCEP_MR.clm2.h1.2005-12-22-00000.nc';
file_ctrl_06(2,:) = 'CLM45_NewControl_CRUNCEP_MR.clm2.h1.2006-01-06-00000.nc';
file_ctrl_06(3,:) = 'CLM45_NewControl_CRUNCEP_MR.clm2.h1.2006-01-21-00000.nc';
file_ctrl_06(4,:) = 'CLM45_NewControl_CRUNCEP_MR.clm2.h1.2006-02-05-00000.nc';
file_ctrl_06(5,:) = 'CLM45_NewControl_CRUNCEP_MR.clm2.h1.2006-02-20-00000.nc';
file_ctrl_06(6,:) = 'CLM45_NewControl_CRUNCEP_MR.clm2.h1.2006-03-07-00000.nc';
file_ctrl_06(7,:) = 'CLM45_NewControl_CRUNCEP_MR.clm2.h1.2006-03-22-00000.nc';

file_ctrl_07(1,:) = 'CLM45_NewControl_CRUNCEP_MR.clm2.h1.2007-01-01-00000.nc';
file_ctrl_07(2,:) = 'CLM45_NewControl_CRUNCEP_MR.clm2.h1.2007-01-16-00000.nc';
file_ctrl_07(3,:) = 'CLM45_NewControl_CRUNCEP_MR.clm2.h1.2007-01-31-00000.nc';
file_ctrl_07(4,:) = 'CLM45_NewControl_CRUNCEP_MR.clm2.h1.2007-02-15-00000.nc';
file_ctrl_07(5,:) = 'CLM45_NewControl_CRUNCEP_MR.clm2.h1.2007-03-02-00000.nc';
file_ctrl_07(6,:) = 'CLM45_NewControl_CRUNCEP_MR.clm2.h1.2007-03-17-00000.nc';


%--------------------------------------------------------------------------
%----------------------------  site locations  ----------------------------
%--------------------------------------------------------------------------
Abisko_loc = [16 169];      % 18.8206E, 68.3556N
Alptal_loc = [8 146];       % 8.8E, 47.05N
Borden_loc = [225 144];     % 79.9333W == 280.0667E, 44.3167N
Cherskiy_loc = [130 169];   % 161.45482E, 68.75574N
Seehornwald_loc = [9 146];  % 9.8558E, 46.8153N
Sodankyla_loc = [22 168];   % 26.6333E, 67.3667N
Yakutsk_loc = [105 163];    % 129.6189E, 62.255N
% sparse site close-ish to Sodankyla
Sparse_loc = [25 172];      % 30E, 71.15N


%--------------------------------------------------------------------------
%------------------  import of global simulation output  ------------------
%--------------------------------------------------------------------------

%-------------------------------  general  -------------------------------%
% longitude
bla = ncread(file_ctrl_04(1,:),'lon');
lon = nan(size(bla));
for x=1:length(lon)
    lon(x) = bla(x);
end

% latitude
bla = ncread(file_ctrl_04(1,:),'lat');
lat = nan(size(bla));
for y=1:length(lat)
    lat(y) = bla(y);
end

% time (each file contains 360 time steps) - 1h shift from UTC to CET
time_04 = nan(length(file_ctrl_04(:,1))*360,1);
for n=1:length(file_ctrl_04(:,1))
    bla = ncread(file_ctrl_04(n,:),'time');
    time_04(1+(n-1)*360:n*360) = bla(:) + datenum(2004,01,01,00,00,00) + 1/24;
end
time_05 = nan(length(file_ctrl_05(:,1))*360,1);
for n=1:length(file_ctrl_05(:,1))
    bla = ncread(file_ctrl_05(n,:),'time');
    time_05(1+(n-1)*360:n*360) = bla(:) + datenum(2004,01,01,00,00,00) + 1/24;
end
time_06 = nan(length(file_ctrl_06(:,1))*360,1);
for n=1:length(file_ctrl_06(:,1))
    bla = ncread(file_ctrl_06(n,:),'time');
    time_06(1+(n-1)*360:n*360) = bla(:) + datenum(2004,01,01,00,00,00) + 1/24;
end
time_07 = nan(length(file_ctrl_07(:,1))*360,1);
for n=1:length(file_ctrl_07(:,1))
    bla = ncread(file_ctrl_07(n,:),'time');
    time_07(1+(n-1)*360:n*360) = bla(:) + datenum(2004,01,01,00,00,00) + 1/24;
end

NEBTs = 3-1;
vegetated = 1;

%----------------------------  sub-canopy LWR  ----------------------------
LWsub_ctrl_Alp_04 = nan(length(file_ctrl_04(:,1))*360,1);
for n=1:length(file_ctrl_04(:,1))
    bla = PFTcreator(file_ctrl_04(n,:),'LWSUB',NEBTs,length(lon),length(lat),360);
    LWsub_ctrl_Alp_04(1+(n-1)*360:n*360) = squeeze(bla(Alptal_loc(1),Alptal_loc(2),:));
end
LWsub_ctrl_Alp_05 = nan(length(file_ctrl_05(:,1))*360,1);
for n=1:length(file_ctrl_05(:,1))
    bla = PFTcreator(file_ctrl_05(n,:),'LWSUB',NEBTs,length(lon),length(lat),360);
    LWsub_ctrl_Alp_05(1+(n-1)*360:n*360) = squeeze(bla(Alptal_loc(1),Alptal_loc(2),:));
end
LWsub_ctrl_Alp_06 = nan(length(file_ctrl_06(:,1))*360,1);
for n=1:length(file_ctrl_06(:,1))
    bla = PFTcreator(file_ctrl_06(n,:),'LWSUB',NEBTs,length(lon),length(lat),360);
    LWsub_ctrl_Alp_06(1+(n-1)*360:n*360) = squeeze(bla(Alptal_loc(1),Alptal_loc(2),:));
end
LWsub_ctrl_Alp_07 = nan(length(file_ctrl_07(:,1))*360,1);
for n=1:length(file_ctrl_07(:,1))
    bla = PFTcreator(file_ctrl_07(n,:),'LWSUB',NEBTs,length(lon),length(lat),360);
    LWsub_ctrl_Alp_07(1+(n-1)*360:n*360) = squeeze(bla(Alptal_loc(1),Alptal_loc(2),:));
end

toc
elapsedTime = toc;

save('LightbulbAnalysis_Alptal_Control.mat','elapsedTime','lon','lat',...
    'time_04','time_05','time_06','time_07',...
    'LWsub_ctrl_Alp_04','LWsub_ctrl_Alp_05','LWsub_ctrl_Alp_06',...
    'LWsub_ctrl_Alp_07');
