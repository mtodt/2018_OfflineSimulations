function out = GridCellCreator(file,variable,llon,llat,ltime)
%{
Snow (and likely soil) properties come, if not already averaged over grid
cells, as 2d-arrays for all landunits:
    - c: column
    - t: time step
The aim of this function is to run through all columns and landunits to put
together a 3d array of longitude x latitude x time that represents a 
weighted sum of all columns over a particular grid cell.
Input parameters:
    - file:     file name
    - variable: variable within file for which to create 3d array
    - dimensions longitude, latitude, and time.
%}

%------------------  importing parameters and variables  -----------------%
i_cols = ncread(file,'cols1d_ixy');
j_cols = ncread(file,'cols1d_jxy');
idx_lunit = ncread(file,'cols1d_itype_lunit');
active_cols = ncread(file,'cols1d_active');
weight_cell = ncread(file,'cols1d_wtgcell');
var = ncread(file,variable);

%------------------------------  processing  -----------------------------%
out = nan(llon,llat,ltime);
for t=1:ltime
    weighting = nan(llon,llat);
    for c=1:length(idx_lunit)
        if active_cols(c) == 1
            if isnan(out(i_cols(c),j_cols(c),t)) && ~isnan(var(c,t))
                out(i_cols(c),j_cols(c),t) = 0;
                weighting(i_cols(c),j_cols(c)) = 0;
            end
            if ~isnan(var(c,t))
                out(i_cols(c),j_cols(c),t) = out(i_cols(c),j_cols(c),t) ...
                    + var(c,t)*weight_cell(c);
                weighting(i_cols(c),j_cols(c)) ...
                    = weighting(i_cols(c),j_cols(c)) + weight_cell(c);
            end
        end
    end
    out(:,:,t) = squeeze(out(:,:,t))./weighting;
end

end